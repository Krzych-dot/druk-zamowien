function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Dodanie logo (zakłada, że plik logo.png znajduje się w tym samym folderze co index.html)
    doc.addImage('logo.png', 'PNG', 10, 10, 50, 20);  // X, Y, szerokość, wysokość logo

    // Zbieranie danych z formularza
    const zaslona = document.getElementById("zaslona").value;
    const szerokosc = document.getElementById("szerokosc").value;
    const wysokosc = document.getElementById("wysokosc").value;

    // Sprawdzanie, czy wszystkie pola są wypełnione
    if (!szerokosc || !wysokosc) {
        alert("Proszę wypełnić wszystkie pola!");
        return;
    }

    // Rozpoczynanie generowania PDF
    doc.setFontSize(16);
    doc.text("Zamówienie Zasłony", 10, 40);

    // Wstawianie szczegółów zamówienia
    doc.setFontSize(12);
    doc.text(`Wariant zasłony: ${zaslona}`, 10, 50);
    doc.text(`Szerokość: ${szerokosc} cm`, 10, 60);
    doc.text(`Wysokość: ${wysokosc} cm`, 10, 70);

    // Dodanie tabeli
    const data = [
        ['Wariant Zasłony', 'Szerokość', 'Wysokość'],
        [zaslona, szerokosc, wysokosc]
    ];

    // Dodanie tabeli do PDF
    doc.autoTable({
        head: data.slice(0, 1),
        body: data.slice(1),
        startY: 80
    });

    // Generowanie pliku PDF
    doc.save("zamowienie.pdf");
}
